Please find instructions at:
https://docs.google.com/document/d/1CU0ljT_W2iXo1KwC07rFqpTt2M6yiev38M0HvfaBtTk/edit?usp=sharing

