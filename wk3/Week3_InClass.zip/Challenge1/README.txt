Please find instructions at:
https://docs.google.com/document/d/13WG2HN77JXBcGppw0pqBkOTbL70G8dZDLPN2PPG_M-Q/edit?usp=sharing

