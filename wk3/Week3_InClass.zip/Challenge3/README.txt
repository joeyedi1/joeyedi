Please find instructions at:
https://docs.google.com/document/d/1KMu-nQip4G01XZ7OxsQAHN-NNsYSGo8Wk2-mKpMMVF0/edit?usp=sharing

