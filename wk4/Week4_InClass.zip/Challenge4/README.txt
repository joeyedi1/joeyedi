Please find instructions at:
https://docs.google.com/document/d/17cKZo9cMbbab6e7hJzReKtpAoqKgTSUsWK5bb84fKFE/edit?usp=drive_link
