Please find instructions at:
https://docs.google.com/document/d/1369yg-WYdgnEsdjrKmkyhgBfKGeBfGteia3VmJ0NPus/edit?usp=drive_link

