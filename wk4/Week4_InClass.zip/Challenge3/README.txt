Please find instructions at:
https://docs.google.com/document/d/145mM9qrQC8KTGsO7BJtm8SKx5egYeubQo_bgWDC5Tns/edit?usp=drive_link
