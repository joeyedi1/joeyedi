Please find instructions at:
https://docs.google.com/document/d/1PW1h4G_nBiBcLmnLpxOqv4tdHFjMmO3S11tN6_f_96E/edit?usp=drive_link
