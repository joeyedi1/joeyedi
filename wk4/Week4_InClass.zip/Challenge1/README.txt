Please find instructions at:
https://docs.google.com/document/d/1jHqzXsUTRIEbmFWdSxLgIXvyt0WY2a5APnjz-KEms4k/edit?usp=drive_link
