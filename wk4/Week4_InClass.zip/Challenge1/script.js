function calculate() {

    // YOUR CODE GOES HERE
    
}